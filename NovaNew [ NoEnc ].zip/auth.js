const fs = require('fs');
const crypto = require('crypto');
const loginFile = './lib/loginStatus.json';

const SECRET_KEY = crypto.createHash('sha256').update(String(process.env.SECRET_KEY || 'xA9vP+eL5r3zT8nK1YqB72WfRtXoU0Mb')).digest('base64').substr(0, 32);

function encrypt(text) {
  const iv = crypto.randomBytes(16);
  const cipher = crypto.createCipheriv('aes-256-cbc', Buffer.from(SECRET_KEY, 'utf8'), iv);
  let encrypted = cipher.update(text, 'utf8', 'base64');
  encrypted += cipher.final('base64');
  return JSON.stringify({ iv: iv.toString('base64'), encryptedData: encrypted });
}

function decrypt(encryptedObject) {
  try {
    const parsedObject = JSON.parse(encryptedObject);
    const iv = Buffer.from(parsedObject.iv, 'base64');
    const encryptedText = Buffer.from(parsedObject.encryptedData, 'base64');
    const decipher = crypto.createDecipheriv('aes-256-cbc', Buffer.from(SECRET_KEY, 'utf8'), iv);
    let decrypted = decipher.update(encryptedText, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
  } catch (error) {
    console.error("Decryption Error:", error.message);
    return null;
  }
}

function saveLoginStatus(username, expiredDate, role) {
  return new Promise((resolve, reject) => {
    try {
      const data = JSON.stringify({ isLoggedIn: true, username, expiredDate, role });
      const encryptedData = encrypt(data);
      fs.writeFileSync(loginFile, encryptedData, 'utf-8');
      resolve(); // Berhasil menyimpan
    } catch (error) {
      reject(error); // Gagal menyimpan
    }
  });
}

module.exports = { saveLoginStatus };