const TelegramBot = require('node-telegram-bot-api');
const { saveLoginStatus } = require('./auth');
const fs = require('fs');
const pendingLoginFile = './lib/pendingLoginRequests.json';

// Token bot dan inisialisasi bot
const token = '7801284547:AAF7dqGdIEPxymCKe3RJ3HQdGTidLk6DFV8';
const bot = new TelegramBot(token, { polling: true });

// Simpan daftar permintaan login yang menunggu persetujuan
const pendingLoginRequests = {};

// Fungsi untuk menyimpan status approval
function savePendingLoginRequest(username, status) {
  let pendingRequests = {};
  if (fs.existsSync(pendingLoginFile)) {
    pendingRequests = JSON.parse(fs.readFileSync(pendingLoginFile, 'utf-8'));
  }
  pendingRequests[username] = { ...pendingRequests[username], status };
  fs.writeFileSync(pendingLoginFile, JSON.stringify(pendingRequests, null, 2), 'utf-8');
  console.log(`[ \x1b[38;5;214mINFO\x1b[0m ] \x1b[38;2;128;128;128mStatus For ${username} Updated To ${status}\n`); // Debugging
}

// Fungsi untuk mengirim permintaan login ke admin
function sendLoginRequest(username, expiredDate, role) {
  pendingLoginRequests[username] = { expiredDate, role, status: 'pending' };

  // Kirim pesan ke admin
  bot.sendMessage(
    '5751218997', // Ganti dengan chat ID admin
    `🔐 New Login Request:\n\n⤷ Username: ${username}\n⤷ Role: ${role}\n⤷ Expired Date: ${expiredDate}\n\n⤷ Use /approve ${username} or /reject ${username}`
  );
}

// Handle perintah /approve
bot.onText(/\/approve (.+)/, (msg, match) => {
  const username = match[1];
  const request = pendingLoginRequests[username];

  if (request && request.status === 'pending') {
    request.status = 'Approved';

    // Simpan status approval ke file
    savePendingLoginRequest(username, 'approved');

    // Simpan status login ke loginStatus.json
    saveLoginStatus(username, request.expiredDate, request.role)
      .then(() => {
        bot.sendMessage(msg.chat.id, `✅ Login Request For ${username} Has Been Approved!.`);
        console.log(`\x1b[38;2;128;128;128mLogin Approved!. Welcome, ${username}\x1b[0m.`); // Notifikasi ke console
        process.exit(1);
      })
      .catch((err) => {
        console.error('Error Saving Login Status:', err.message);
        bot.sendMessage(msg.chat.id, `❌ Failed To Approve Login Request For ${username}.`);
      });
  } else {
    bot.sendMessage(msg.chat.id, `❌ No Pending Login Request Found For ${username}.`);
  }
});

// Handle perintah /reject
bot.onText(/\/reject (.+)/, (msg, match) => {
  const username = match[1];
  const request = pendingLoginRequests[username];

  if (request && request.status === 'pending') {
    request.status = 'Rejected';
    bot.sendMessage(msg.chat.id, `❌ Login Request For ${username} Has Been Rejected.`);
  } else {
    bot.sendMessage(msg.chat.id, `❌ No Pending Login Request Found For ${username}.`);
  }
});

module.exports = { sendLoginRequest };